-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2025 at 11:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_rental_app_vue`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `model` varchar(30) NOT NULL,
  `year` int(11) NOT NULL,
  `car_type` varchar(30) NOT NULL,
  `daily_rent_price` decimal(6,2) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `name`, `brand`, `model`, `year`, `car_type`, `daily_rent_price`, `availability`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Axio', 'Toyota', '2015', 2021, 'Sedan', 3500.00, 1, 'uploads/car1.jpg', '2025-05-06 14:30:28', '2025-05-10 04:05:28'),
(2, 'BMW iX', 'BMW', 'MY25-iX', 2020, 'SUV Electric', 6000.00, 1, 'uploads/car2.jpg', '2025-05-06 14:30:28', '2025-05-10 04:05:12'),
(3, 'CH-R', 'Toyota', '2018', 2023, 'SUV', 4500.00, 1, 'uploads/car3.jpg', '2025-05-06 14:30:28', '2025-05-10 04:06:11'),
(4, 'Almera', 'Nissan', '2022', 2022, 'Sedan', 4000.00, 1, 'uploads/car4.jpg', '2025-05-06 14:30:28', '2025-05-10 13:59:59'),
(5, 'Model Y', 'Tesla', '2023', 2023, 'Sedan Electric', 5500.00, 1, 'uploads/car5.jpg', '2025-05-06 14:30:28', '2025-05-10 04:06:56'),
(6, 'Thunder', 'Audi', '2020', 2025, 'Sports', 5000.00, 1, 'uploads/car-1746638282-ildar-garifullin-uX4Bjke_xUE-unsplash.jpg', '2025-05-07 11:18:02', '2025-05-07 11:18:02'),
(7, 'Rustom', 'Mahindra', '2022', 2025, 'SUV', 3000.00, 1, 'uploads/car-1746638584-kenny-eliason-yDekvyZ52dU-unsplash (1).jpg', '2025-05-07 11:23:04', '2025-05-10 04:05:39'),
(8, 'Electra', 'Ford', '2022', 2024, 'Hybrid', 4000.00, 1, 'uploads/car-1746638649-sven-d-a4S6KUuLeoM-unsplash.jpg', '2025-05-07 11:24:09', '2025-05-07 11:24:09'),
(13, 'Mustang', 'Ford', '1969', 2024, 'Vintage', 6000.00, 1, 'uploads/car-1746907165-jakob-owens-U_2kP7bkFKw-unsplash.jpg', '2025-05-10 13:59:25', '2025-05-10 13:59:25');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_05_02_182224_create_cars_table', 1),
(5, '2025_05_02_182252_create_rentals_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_cost` decimal(8,2) NOT NULL,
  `status` enum('ongoing','completed','cancelled') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`id`, `user_id`, `car_id`, `start_date`, `end_date`, `total_cost`, `status`, `created_at`, `updated_at`) VALUES
(3, 8, 6, '2025-05-08', '2025-05-08', 5000.00, 'completed', '2025-05-07 14:18:16', '2025-05-07 14:25:21'),
(4, 8, 6, '2025-05-09', '2025-05-09', 5000.00, 'completed', '2025-05-07 14:18:54', '2025-05-07 14:25:33'),
(7, 12, 7, '2025-05-29', '2025-05-31', 6000.00, 'cancelled', '2025-05-07 14:55:47', '2025-05-10 03:57:00'),
(16, 12, 4, '2025-05-20', '2025-05-21', 8000.00, 'cancelled', '2025-05-10 04:10:25', '2025-05-10 04:10:48'),
(17, 12, 5, '2025-05-22', '2025-05-23', 11000.00, 'cancelled', '2025-05-10 04:12:59', '2025-05-10 04:13:32'),
(19, 12, 3, '2025-05-25', '2025-05-26', 9000.00, 'cancelled', '2025-05-10 13:52:08', '2025-05-10 13:52:26'),
(20, 12, 5, '2025-05-19', '2025-05-20', 11000.00, 'cancelled', '2025-05-10 13:57:56', '2025-05-10 13:58:23'),
(21, 12, 3, '2025-05-20', '2025-05-25', 27000.00, 'ongoing', '2025-05-10 14:00:58', '2025-05-10 14:00:58');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('DmC9ZVXhtL0i25hHBw0jNCFTJd17oVEWyceffQv3', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMGdpQ1ZWaktnUjMycWpvMG9hMEVUUVpXTHZvM3BNSGQ2YTNabzRqMCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9jYXJzIjt9fQ==', 1746907298);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `address`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Harry Potter', 'admin@admin.com', '7072824359', 'Harum at ea hic quibusdam vitae quia facilis blanditiis amet at quam dolorem aut.', '$2y$12$N6Fp55EYoaOmqOR.jiWroO6wAOsjR2bNYeVfnONsIyt9XyS4B4m06', 'admin', NULL, NULL, NULL),
(2, 'Hasnat Abdullah', 'fGotOh0QEf@example.com', '1885425534', 'Eius doloribus voluptatem deserunt sint sed ut.', '$2y$12$AkplZWAFUrp1AJOfkh3gMuH15yjbnMjAS2A8JUMv8wvtpDJqxAv62', 'customer', NULL, NULL, NULL),
(3, 'Dipty Chowdhruy', 'TNIOM3WnNi@example.com', '9330903131', 'Autem eveniet natus sit unde voluptas consequatur consequuntur exercitationem quibusdam minus sint voluptatum.', '$2y$12$f2BCw/rq7QgaR/ZnqrjPHe2T7F.AqMbBbnXfbscwsAVvFlFxd4T5m', 'customer', NULL, NULL, NULL),
(4, 'Sarjis Alom', 'bEuUunMwun@example.com', '8790218967', 'Numquam velit ut aut minus doloribus quaerat omnis nisi nostrum.', '$2y$12$BSruJOZ.AQicdz1NYXoFZOAaaoycXybFADFpUXg.dF8N9riuNcDjm', 'customer', NULL, NULL, NULL),
(5, 'Sadia Sraboni', 'Pp6oKNbCw1@example.com', '9214363273', 'Amet dolores qui aliquam molestiae laboriosam et.', '$2y$12$oLyH8vxugFno2YbW6uyFiOu.OK1g0YIhySxlcs6RCpvNzslI/kD8K', 'customer', NULL, NULL, NULL),
(6, 'Test Test', 'test@test.com', '01336545645', 'Test, Test\nTST 11245', '$2y$12$2PM5vNCXT5WE9xX59LyAbOIzYySxVXibEyNfXK2479kNHOa.3Lfmq', 'customer', NULL, '2025-05-06 08:37:49', '2025-05-06 08:41:28'),
(8, 'Test 3', 'test3@test.com', NULL, NULL, '$2y$12$C1eCgXBodrGlu6iETGU3Fu0i3yxbO4YSKmmLZJO6FHSTA9s47kLYW', 'customer', NULL, '2025-05-07 11:02:43', '2025-05-07 11:02:43'),
(12, 'Car Lover', 'dhrubo.luke@gmail.com', NULL, NULL, '$2y$12$CWRTDJRk81qtevNGeEtrReWgfdC1pwYkZ7O096bj0dYp.q0Zu2Op2', 'customer', NULL, '2025-05-07 14:50:28', '2025-05-07 14:50:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rentals_user_id_foreign` (`user_id`),
  ADD KEY `rentals_car_id_foreign` (`car_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_car_id_foreign` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `rentals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
